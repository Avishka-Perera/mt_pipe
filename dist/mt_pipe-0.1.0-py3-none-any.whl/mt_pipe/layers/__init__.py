"""Initialization of the layers subpackage"""

from .linear_head import LinearHead

__all__ = ["LinearHead"]
