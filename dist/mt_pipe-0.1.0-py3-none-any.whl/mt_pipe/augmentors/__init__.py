"""Initialization of the augmentors subpackage"""

from ._base import Augmentor

__all__ = ["Augmentor"]
